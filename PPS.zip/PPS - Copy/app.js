const express = require('express');
const path = require('path');
const mysql = require('mysql');

const app = express();
const PORT = 8080;

// Set the static folder
app.use(express.static(path.join(__dirname, 'public')));

// Create a MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'uaspps'
});

// Connect to the database
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the database');
});

// Define route to fetch products from the database
app.get('/products', (req, res) => {
  const query = 'SELECT * FROM product';
  connection.query(query, (err, rows) => {
    if (err) throw err;
    res.json(rows);
  });
});

// Define route to add product to Wishlist
app.post('/wishlist', (req, res) => {
  const { productId } = req.body;
  const selectQuery = 'SELECT id FROM product WHERE id = ?';
  connection.query(selectQuery, [productId], (err, rows) => {
    if (err) throw err;
    if (rows.length === 0) {
      res.status(404).send('Product not found');
    } else {
      const insertQuery = 'INSERT INTO wishlist (product_id) VALUES (?)';
      connection.query(insertQuery, [productId], (err, result) => {
        if (err) throw err;
        res.sendStatus(200);
      });
    }
  });
});

// Define route to add product to Cart
app.post('/cart', (req, res) => {
  const { productId } = req.body;
  const selectQuery = 'SELECT id FROM product WHERE id = ?';
  connection.query(selectQuery, [productId], (err, rows) => {
    if (err) throw err;
    if (rows.length === 0) {
      res.status(404).send('Product not found');
    } else {
      const insertQuery = 'INSERT INTO cart (product_id, quantity) VALUES (?, 1)';
      connection.query(insertQuery, [productId], (err, result) => {
        if (err) throw err;
        res.sendStatus(200);
      });
    }
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
